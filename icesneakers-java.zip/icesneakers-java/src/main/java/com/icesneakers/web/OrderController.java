package com.icesneakers.web;

import com.icesneakers.dto.Dtos.*;
import com.icesneakers.service.AuthService;
import com.icesneakers.service.OrderService;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/orders")
public class OrderController {

    private final OrderService orders;
    private final AuthService auth;

    public OrderController(OrderService orders, AuthService auth) {
        this.orders = orders;
        this.auth = auth;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public OrderDto checkout(@Valid @RequestBody CheckoutRequest r, HttpSession s) {
        return orders.checkout(auth.requireUser(s), r, s);
    }

    @GetMapping
    public List<OrderDto> mine(HttpSession s) {
        return orders.mine(auth.requireUser(s));
    }

    @GetMapping("/{id}")
    public OrderDto get(@PathVariable Long id, HttpSession s) {
        return orders.getMine(auth.requireUser(s), id);
    }

    @PostMapping("/{id}/cancel")
    public OrderDto cancel(@PathVariable Long id, HttpSession s) {
        return orders.cancelMine(auth.requireUser(s), id);
    }
}
