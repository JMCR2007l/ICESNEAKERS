'use strict';
(async function () {
    await ICE.ready;
    const cont = document.getElementById('destacados');
    try {
        const r = await api('/products?destacados=true&size=8');
        cont.innerHTML = r.items.length ? r.items.map(productCard).join('')
            : '<div class="estadovacio"><h3>Aún no hay destacados</h3></div>';
    } catch (e) {
        cont.innerHTML = '<div class="estadovacio"><h3>No pudimos cargar los productos</h3><p>' + esc(e.message) + '</p></div>';
    }
    try {
        const p = await api('/products/dunk-ice');
        document.getElementById('promopiezas').textContent =
            p.stock > 0 ? 'Quedan ' + p.stock + ' piezas exclusivas' : 'Agotado';
        document.getElementById('promoprecio').textContent =
            '¡Llévate la tuya por ' + money(p.price) + (p.oldPrice ? ' (antes ' + money(p.oldPrice) + ')' : '') + '!';
        document.getElementById('promoboton').href = 'producto.html?slug=dunk-ice';
        document.getElementById('promoboton').textContent = 'Ver Dunk ICE';
    } catch (e) { /* se queda el texto original */ }
})();
