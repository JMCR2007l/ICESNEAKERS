'use strict';
(async function () {
    await ICE.ready;
    const root = document.getElementById('contenido');

    if (!ICE.user) { location.replace('login.html?next=checkout.html'); return; }
    if (!ICE.cart || ICE.cart.lines.length === 0) {
        root.innerHTML = '<div class="panel estadovacio"><h3>No hay nada que pagar</h3><p>Tu carrito está vacío.</p><br><a class="botonnegro" href="catalogo.html">Ver catálogo</a></div>';
        return;
    }

    const c = ICE.cart;
    const items = c.lines.map(l => `<div class="fila"><span>${esc(l.name)} · T${esc(l.size)} × ${l.quantity}</span><span>${money(l.lineTotal)}</span></div>`).join('');

    root.innerHTML = `
        <form class="doscolumnas" id="form" novalidate>
            <div class="columnaprincipal">
                <div class="panel">
                    <h3 style="margin-bottom:16px">Datos de envío</h3>
                    <div id="error" class="mensaje error oculto"></div>
                    <div class="formulario">
                        <div class="campo ancho"><label for="fullName">Nombre completo</label><input id="fullName" value="${esc(ICE.user.name)}" maxlength="120" required></div>
                        <div class="campo"><label for="phone">Teléfono</label><input id="phone" type="tel" placeholder="6691234567" maxlength="20" required></div>
                        <div class="campo"><label for="zip">Código postal</label><input id="zip" inputmode="numeric" placeholder="82000" maxlength="5" required></div>
                        <div class="campo ancho"><label for="street">Calle y número</label><input id="street" maxlength="160" required></div>
                        <div class="campo"><label for="city">Ciudad</label><input id="city" maxlength="80" required></div>
                        <div class="campo"><label for="state">Estado</label><input id="state" maxlength="80" required></div>
                    </div>
                </div>
                <div class="panel" style="margin-top:20px">
                    <h3 style="margin-bottom:16px">Método de pago</h3>
                    <div class="metodospago">
                        <label><input type="radio" name="pago" value="TARJETA" checked><span>Tarjeta</span></label>
                        <label><input type="radio" name="pago" value="OXXO"><span>OXXO</span></label>
                        <label><input type="radio" name="pago" value="TRANSFERENCIA"><span>Transferencia</span></label>
                    </div>
                    <p class="pista">Demo: el pago es simulado, no se cobra nada ni se piden datos de tarjeta. Con tarjeta el pedido queda «Pagado»; con OXXO o transferencia queda «Pendiente».</p>
                </div>
            </div>
            <aside class="panel resumenpanel">
                <h3>Tu pedido</h3>
                ${items}
                <hr style="border:none;border-top:1px solid #ddd;margin:12px 0">
                ${resumenHtml(c)}
                <br><button class="botonnegro" style="width:100%" id="pagar" type="submit">Confirmar pedido · ${money(c.total)}</button>
            </aside>
        </form>`;

    const $ = id => document.getElementById(id);
    $('form').addEventListener('submit', async ev => {
        ev.preventDefault();
        const err = $('error');
        err.classList.add('oculto');
        const body = {
            fullName: $('fullName').value, phone: $('phone').value, street: $('street').value,
            city: $('city').value, state: $('state').value, zip: $('zip').value,
            paymentMethod: document.querySelector('input[name=pago]:checked').value
        };
        $('pagar').disabled = true;
        try {
            const o = await api('/orders', { method: 'POST', body });
            setCart(await api('/cart'));
            root.innerHTML = `
                <div class="panel exito">
                    <div class="circulo">✓</div>
                    <h2>¡Gracias por tu compra!</h2>
                    <p style="margin:10px 0">Pedido <b>#${o.id}</b> · ${o.status === 'PAGADO' ? 'Pago recibido' : 'Pendiente de pago'} · Total ${money(o.total)}</p>
                    <p style="color:#555">Enviaremos tu pedido a ${esc(o.address)}.</p><br>
                    <a class="botonnegro" href="cuenta.html">Ver mis pedidos</a>
                    <a class="botonsecundario" href="catalogo.html">Seguir comprando</a>
                </div>`;
            window.scrollTo(0, 0);
        } catch (e) {
            err.textContent = e.message;
            err.classList.remove('oculto');
            err.scrollIntoView({ behavior: 'smooth', block: 'center' });
            $('pagar').disabled = false;
        }
    });
})();
