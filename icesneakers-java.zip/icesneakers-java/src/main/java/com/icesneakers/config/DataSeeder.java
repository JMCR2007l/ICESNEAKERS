package com.icesneakers.config;

import com.icesneakers.model.Enums.Gender;
import com.icesneakers.model.Enums.Role;
import com.icesneakers.model.Product;
import com.icesneakers.repo.ProductRepository;
import com.icesneakers.repo.UserRepository;
import com.icesneakers.service.AuthService;
import java.math.BigDecimal;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

/** Carga el catalogo original de ICE sneakers y dos usuarios de prueba la primera vez que arranca. */
@Component
public class DataSeeder implements CommandLineRunner {

    private static final Logger log = LoggerFactory.getLogger(DataSeeder.class);
    private static final String SIZES = "25,25.5,26,26.5,27,27.5,28,28.5,29";

    private final ProductRepository products;
    private final UserRepository users;
    private final AuthService auth;

    public DataSeeder(ProductRepository products, UserRepository users, AuthService auth) {
        this.products = products;
        this.users = users;
        this.auth = auth;
    }

    @Override
    public void run(String... args) {
        if (products.count() == 0) {
            add("dunk-ice", "Dunk ICE", "Nike Dunk x ICE sneakers",
                    "Edicion exclusiva de la casa: 100 piezas numeradas en gris y blanco. Cuando se acaben, no vuelven.",
                    "4999", "6499", "imagenes/dunk-ice.png", Gender.UNISEX, true, 100);
            add("jordan-1-dior", "Jordan 1 Dior", "Dior x Jordan",
                    "Edición limitada de 2020 hecha en Italia: piel de becerro en gris, Swoosh con el estampado Dior Oblique y la leyenda «AIR DIOR» en el tobillo.",
                    "87817", null, "imagenes/jordan1-dior.png", Gender.HOMBRE, true, 3);
            add("forum-bad-bunny", "Forum Bad Bunny", "Bad Bunny x adidas",
                    "Segunda colaboración del cantante puertorriqueño con adidas: piel rosa combinada con ante, correa con hebilla y suela semitranslúcida.",
                    "6403", null, "imagenes/badbuny.png", Gender.MUJER, true, 14);
            add("jordan-1-travis", "Jordan 1 Travis", "Travis Scott x Jordan",
                    "Jordan 1 Low en colaboración con Travis Scott: Swoosh invertido en rojo y carita de Cactus Jack.",
                    "7994", null, "imagenes/jordan1-pink.png", Gender.MUJER, true, 9);
            add("nike-sb-dunk-low", "Nike SB Dunk Low", "Concepts x Nike SB",
                    "Edición de 2022 con Concepts, tienda de Boston: tonos naranja con detalles moteados, tres opciones de agujetas y una inspiración en la langosta de Nueva Inglaterra.",
                    "6226", null, "imagenes/dunk-naranja.png", Gender.UNISEX, true, 12);
            add("jordan-1-chicago", "Jordan 1 Chicago", "Off-White x Jordan",
                    "De la colección «The Ten» de Virgil Abloh (2017): espuma expuesta, Swoosh cosido, la leyenda «AIR» en la suela y su característica cinta roja.",
                    "42747", null, "imagenes/jordan1-offwhite.png", Gender.HOMBRE, false, 4);
            add("jordan-1-alaska", "Jordan 1 Alaska", "Virgil Abloh Archive x Jordan",
                    "Reedición 2026 del archivo de Virgil Abloh: todo en blanco inspirado en paisajes nevados, con cinta de plástico, espuma expuesta y «AIR» en la suela.",
                    "11599", null, "imagenes/jordan1-alaska.png", Gender.HOMBRE, false, 8);
            add("dunk-low-cactus-jack", "Dunk Low Cactus Jack", "Travis Scott x Nike SB",
                    "Lanzado en febrero de 2020: lona caqui con detalles azul marino de bandana, Swoosh desigual en negro y rosa, panel de tartán y agujetas de cuerda.",
                    "14479", null, "imagenes/dunk-travis.png", Gender.HOMBRE, false, 6);
            add("jordan-1-low-fragment", "Jordan 1 Low Fragment", "Travis Scott x fragment x Jordan",
                    "Jordan 1 Low de Travis Scott y fragment design: Swoosh invertido en azul militar, doble rayo de fragment en el talón y carita de Cactus Jack.",
                    "18754", null, "imagenes/jordan1-fragment.png", Gender.HOMBRE, false, 5);
            log.info("Catalogo inicial cargado ({} productos)", products.count());
        }
        if (users.count() == 0) {
            auth.createUser("Administrador", "admin@icesneakers.com", "Admin1234", Role.ADMIN);
            auth.createUser("Cliente Demo", "cliente@demo.com", "Cliente123", Role.CLIENTE);
            log.info("Usuarios demo: admin@icesneakers.com / Admin1234  y  cliente@demo.com / Cliente123");
        }
    }

    private void add(String slug, String name, String detail, String description, String price, String oldPrice,
                     String image, Gender gender, boolean featured, int stock) {
        Product p = new Product();
        p.setSlug(slug);
        p.setName(name);
        p.setDetail(detail);
        p.setDescription(description);
        p.setPrice(new BigDecimal(price));
        p.setOldPrice(oldPrice == null ? null : new BigDecimal(oldPrice));
        p.setImage(image);
        p.setGender(gender);
        p.setFeatured(featured);
        p.setStock(stock);
        p.setSizes(SIZES);
        products.save(p);
    }
}
