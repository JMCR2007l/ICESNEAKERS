'use strict';
(async function () {
    await ICE.ready;
    const $ = id => document.getElementById(id);
    const next = safeNext(params().get('next'), 'index.html');
    if (ICE.user) { location.replace(next === 'index.html' ? 'cuenta.html' : next); return; }

    function tab(registro) {
        $('tab-login').classList.toggle('activa', !registro);
        $('tab-registro').classList.toggle('activa', registro);
        $('form-login').classList.toggle('oculto', registro);
        $('form-registro').classList.toggle('oculto', !registro);
        $('error').classList.add('oculto');
    }
    $('tab-login').addEventListener('click', () => tab(false));
    $('tab-registro').addEventListener('click', () => tab(true));

    async function enviar(ev, path, body) {
        ev.preventDefault();
        const btn = ev.target.querySelector('button[type=submit]');
        btn.disabled = true;
        $('error').classList.add('oculto');
        try {
            await api(path, { method: 'POST', body });
            location.href = next;
        } catch (e) {
            $('error').textContent = e.message;
            $('error').classList.remove('oculto');
            btn.disabled = false;
        }
    }
    $('form-login').addEventListener('submit', ev =>
        enviar(ev, '/auth/login', { email: $('l-email').value, password: $('l-pass').value }));
    $('form-registro').addEventListener('submit', ev =>
        enviar(ev, '/auth/register', { name: $('r-name').value, email: $('r-email').value, password: $('r-pass').value }));
})();
