package com.icesneakers.repo;

import com.icesneakers.model.AppUser;
import com.icesneakers.model.CustomerOrder;
import com.icesneakers.model.Enums;
import java.math.BigDecimal;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface OrderRepository extends JpaRepository<CustomerOrder, Long> {

    List<CustomerOrder> findByUserOrderByCreatedAtDesc(AppUser user);

    List<CustomerOrder> findAllByOrderByCreatedAtDesc();

    @Query("select sum(o.total) from CustomerOrder o where o.status <> :excluded")
    BigDecimal sumTotalExcluding(@Param("excluded") Enums.OrderStatus excluded);

    /** Ingresos = suma de pedidos no cancelados. */
    default BigDecimal revenue() {
        BigDecimal sum = sumTotalExcluding(Enums.OrderStatus.CANCELADO);
        return sum == null ? BigDecimal.ZERO : sum;
    }
}
