package com.icesneakers.web;

import com.icesneakers.dto.Dtos.*;
import com.icesneakers.model.Enums;
import com.icesneakers.service.ProductService;
import java.math.BigDecimal;
import java.util.List;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/products")
public class ProductController {

    private final ProductService service;

    public ProductController(ProductService service) {
        this.service = service;
    }

    @GetMapping
    public PageResponse<ProductDto> list(@RequestParam(required = false) String q,
                                         @RequestParam(required = false) Enums.Gender genero,
                                         @RequestParam(required = false) BigDecimal min,
                                         @RequestParam(required = false) BigDecimal max,
                                         @RequestParam(defaultValue = "false") boolean oferta,
                                         @RequestParam(defaultValue = "false") boolean destacados,
                                         @RequestParam(required = false) String orden,
                                         @RequestParam(defaultValue = "0") int page,
                                         @RequestParam(defaultValue = "12") int size) {
        return service.search(q, genero, min, max, oferta, destacados, orden, page, size);
    }

    @GetMapping("/{slug}")
    public ProductDto get(@PathVariable String slug) {
        return service.getBySlug(slug);
    }

    @GetMapping("/{slug}/related")
    public List<ProductDto> related(@PathVariable String slug) {
        return service.related(slug);
    }
}
