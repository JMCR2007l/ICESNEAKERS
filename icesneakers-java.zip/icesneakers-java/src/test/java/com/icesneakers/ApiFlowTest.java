package com.icesneakers;

import static org.hamcrest.Matchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.web.servlet.MockMvc;

@SpringBootTest
@AutoConfigureMockMvc
@TestPropertySource(properties = "spring.datasource.url=jdbc:h2:mem:testdb;DB_CLOSE_DELAY=-1")
class ApiFlowTest {

    @Autowired MockMvc mvc;

    private static final String JSON = MediaType.APPLICATION_JSON_VALUE;

    @Test
    void catalogoSeCargaYSeFiltra() throws Exception {
        mvc.perform(get("/api/products?size=50")).andExpect(status().isOk())
                .andExpect(jsonPath("$.total", is(9)));
        mvc.perform(get("/api/products?q=dior")).andExpect(jsonPath("$.items[0].slug", is("jordan-1-dior")));
        mvc.perform(get("/api/products?oferta=true")).andExpect(jsonPath("$.total", is(1)));
        mvc.perform(get("/api/products?orden=precio_asc")).andExpect(jsonPath("$.items[0].slug", is("dunk-ice")));
    }

    @Test
    void compraCompletaDescuentaInventario() throws Exception {
        MockHttpSession s = new MockHttpSession();
        mvc.perform(post("/api/auth/register").session(s).contentType(JSON)
                .content("{\"name\":\"Ana\",\"email\":\"ana@test.com\",\"password\":\"Password1\"}"))
                .andExpect(status().isCreated());

        long id = idOf("jordan-1-chicago"); // stock inicial: 4
        mvc.perform(post("/api/cart/items").session(s).contentType(JSON)
                .content("{\"productId\":" + id + ",\"size\":\"27\",\"quantity\":2}"))
                .andExpect(status().isOk()).andExpect(jsonPath("$.itemCount", is(2)));
        mvc.perform(post("/api/cart/coupon").session(s).contentType(JSON).content("{\"code\":\"ice10\"}"))
                .andExpect(jsonPath("$.discount", is(8549.4)));

        mvc.perform(post("/api/orders").session(s).contentType(JSON).content(
                "{\"fullName\":\"Ana Perez\",\"phone\":\"6691234567\",\"street\":\"Av. Mar 100\",\"city\":\"Mazatlan\","
                        + "\"state\":\"Sinaloa\",\"zip\":\"82000\",\"paymentMethod\":\"TARJETA\"}"))
                .andExpect(status().isCreated()).andExpect(jsonPath("$.status", is("PAGADO")))
                .andExpect(jsonPath("$.shipping", is(0)));

        mvc.perform(get("/api/products/jordan-1-chicago")).andExpect(jsonPath("$.stock", is(2)));
        mvc.perform(get("/api/cart").session(s)).andExpect(jsonPath("$.itemCount", is(0)));
    }

    @Test
    void noSePuedeComprarMasDelStock() throws Exception {
        MockHttpSession s = new MockHttpSession();
        long id = idOf("jordan-1-dior"); // stock 3
        mvc.perform(post("/api/cart/items").session(s).contentType(JSON)
                .content("{\"productId\":" + id + ",\"size\":\"26\",\"quantity\":4}"))
                .andExpect(status().isConflict());
    }

    @Test
    void checkoutRequiereSesionYAdminRequiereRol() throws Exception {
        mvc.perform(post("/api/orders").contentType(JSON).content(
                "{\"fullName\":\"Ana\",\"phone\":\"6691234567\",\"street\":\"Calle 1\",\"city\":\"Mazatlan\","
                        + "\"state\":\"Sinaloa\",\"zip\":\"82000\",\"paymentMethod\":\"OXXO\"}"))
                .andExpect(status().isUnauthorized());
        mvc.perform(get("/api/admin/stats")).andExpect(status().isUnauthorized());

        MockHttpSession cliente = new MockHttpSession();
        mvc.perform(post("/api/auth/login").session(cliente).contentType(JSON)
                .content("{\"email\":\"cliente@demo.com\",\"password\":\"Cliente123\"}")).andExpect(status().isOk());
        mvc.perform(get("/api/admin/stats").session(cliente)).andExpect(status().isForbidden());

        MockHttpSession admin = new MockHttpSession();
        mvc.perform(post("/api/auth/login").session(admin).contentType(JSON)
                .content("{\"email\":\"admin@icesneakers.com\",\"password\":\"Admin1234\"}")).andExpect(status().isOk());
        mvc.perform(get("/api/admin/stats").session(admin)).andExpect(status().isOk())
                .andExpect(jsonPath("$.products", greaterThanOrEqualTo(9)));
    }

    @Test
    void loginIncorrectoEs401() throws Exception {
        mvc.perform(post("/api/auth/login").contentType(JSON)
                .content("{\"email\":\"cliente@demo.com\",\"password\":\"mala-clave\"}"))
                .andExpect(status().isUnauthorized()).andExpect(jsonPath("$.error", notNullValue()));
    }

    private long idOf(String slug) throws Exception {
        String body = mvc.perform(get("/api/products/" + slug)).andReturn().getResponse().getContentAsString();
        return Long.parseLong(body.replaceAll(".*\"id\":(\\d+).*", "$1"));
    }
}
