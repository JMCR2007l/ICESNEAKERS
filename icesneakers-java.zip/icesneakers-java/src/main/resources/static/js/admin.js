'use strict';
(async function () {
    await ICE.ready;
    const $ = id => document.getElementById(id);
    if (!ICE.user) { location.replace('login.html?next=admin.html'); return; }
    if (ICE.user.role !== 'ADMIN') {
        document.querySelector('.pagina').innerHTML = '<div class="panel estadovacio"><h3>Acceso restringido</h3><p>Necesitas una cuenta de administrador.</p><br><a class="botonnegro" href="index.html">Volver al inicio</a></div>';
        return;
    }

    const IMAGENES = ['dunk-ice', 'jordan1-dior', 'badbuny', 'jordan1-pink', 'dunk-naranja', 'jordan1-offwhite',
        'jordan1-alaska', 'dunk-travis', 'jordan1-fragment', 'promocional'].map(n => 'imagenes/' + n + '.png');
    $('imagenes-lista').innerHTML = IMAGENES.map(i => '<option value="' + i + '">').join('');

    let productos = [];
    let editando = null;
    const ESTADOS = ['PENDIENTE', 'PAGADO', 'ENVIADO', 'ENTREGADO', 'CANCELADO'];

    // ---------- Estadisticas ----------
    async function stats() {
        const s = await api('/admin/stats');
        $('estadisticas').innerHTML = `
            <div class="estad"><span>Pedidos</span><strong>${s.orders}</strong></div>
            <div class="estad"><span>Ingresos</span><strong>${money(s.revenue)}</strong></div>
            <div class="estad"><span>Productos</span><strong>${s.products}</strong></div>
            <div class="estad"><span>Usuarios</span><strong>${s.users}</strong></div>
            <div class="estad"><span>Stock bajo (≤10)</span><strong class="${s.lowStock.length ? 'bajostock' : ''}">${s.lowStock.length}</strong></div>`;
    }

    // ---------- Productos ----------
    function tablaProductos() {
        $('tabla-productos').innerHTML = `
            <thead><tr><th></th><th>Producto</th><th>Para</th><th>Precio</th><th>Stock</th><th>Dest.</th><th></th></tr></thead>
            <tbody>${productos.map(p => `
                <tr>
                    <td><img src="${esc(p.image)}" alt=""></td>
                    <td><b>${esc(p.name)}</b><br><small>${esc(p.detail)}</small></td>
                    <td>${esc(p.gender)}</td>
                    <td>${money(p.price)}${p.oldPrice ? '<br><small style="text-decoration:line-through">' + money(p.oldPrice) + '</small>' : ''}</td>
                    <td class="${p.stock <= 10 ? 'bajostock' : ''}">${p.stock}</td>
                    <td>${p.featured ? '★' : ''}</td>
                    <td class="acc"><button data-edit="${p.id}">Editar</button> <button class="peligro" data-del="${p.id}">Eliminar</button></td>
                </tr>`).join('')}</tbody>`;
    }

    async function cargarProductos() {
        productos = await api('/admin/products');
        tablaProductos();
    }

    function abrirModal(p) {
        editando = p ? p.id : null;
        $('modal-titulo').textContent = p ? 'Editar producto' : 'Nuevo producto';
        $('p-name').value = p ? p.name : '';
        $('p-detail').value = p ? (p.detail || '') : '';
        $('p-desc').value = p ? (p.description || '') : '';
        $('p-price').value = p ? p.price : '';
        $('p-old').value = p && p.oldPrice ? p.oldPrice : '';
        $('p-stock').value = p ? p.stock : 10;
        $('p-gender').value = p ? p.gender : 'UNISEX';
        $('p-image').value = p ? p.image : '';
        $('p-sizes').value = p ? p.sizes.join(',') : '25,25.5,26,26.5,27,27.5,28,28.5,29';
        $('p-featured').checked = p ? p.featured : false;
        $('modal-error').classList.add('oculto');
        $('modal').classList.remove('oculto');
    }
    const cerrarModal = () => $('modal').classList.add('oculto');

    $('nuevo').addEventListener('click', () => abrirModal(null));
    $('cancelar').addEventListener('click', cerrarModal);
    $('modal').addEventListener('mousedown', e => { if (e.target === $('modal')) cerrarModal(); });

    $('tabla-productos').addEventListener('click', async e => {
        const t = e.target;
        if (t.dataset.edit) abrirModal(productos.find(p => p.id === Number(t.dataset.edit)));
        if (t.dataset.del) {
            const p = productos.find(x => x.id === Number(t.dataset.del));
            if (!confirm('¿Eliminar «' + p.name + '»? Esta acción no se puede deshacer.')) return;
            try { await api('/admin/products/' + p.id, { method: 'DELETE' }); toast('Producto eliminado'); await cargarProductos(); stats(); }
            catch (err) { toast(err.message, 'error'); }
        }
    });

    $('form-producto').addEventListener('submit', async ev => {
        ev.preventDefault();
        const num = v => (v === '' ? null : Number(v));
        const body = {
            name: $('p-name').value, detail: $('p-detail').value, description: $('p-desc').value,
            price: num($('p-price').value), oldPrice: num($('p-old').value),
            image: $('p-image').value.trim(), gender: $('p-gender').value,
            featured: $('p-featured').checked, stock: Number($('p-stock').value || 0),
            sizes: $('p-sizes').value.split(',').map(s => s.trim()).filter(Boolean)
        };
        try {
            await api(editando ? '/admin/products/' + editando : '/admin/products',
                { method: editando ? 'PUT' : 'POST', body });
            cerrarModal();
            toast('Producto guardado ✓');
            await cargarProductos();
            stats();
        } catch (err) {
            $('modal-error').textContent = err.message;
            $('modal-error').classList.remove('oculto');
        }
    });

    // ---------- Pedidos ----------
    async function cargarPedidos() {
        const os = await api('/admin/orders');
        $('lista-pedidos').innerHTML = os.length ? os.map(o => pedidoHtml(o, {
            admin: true,
            extra: '<p style="margin-top:10px"><label style="font-size:13px;font-weight:bold">Estado: <select data-estado="' + o.id + '">'
                + ESTADOS.map(s => '<option' + (s === o.status ? ' selected' : '') + '>' + s + '</option>').join('')
                + '</select></label></p>'
        })).join('') : '<div class="estadovacio"><h3>Aún no hay pedidos</h3></div>';
    }

    $('lista-pedidos').addEventListener('change', async e => {
        const id = e.target.dataset.estado;
        if (!id) return;
        try {
            await api('/admin/orders/' + id + '/status', { method: 'PATCH', body: { status: e.target.value } });
            toast('Pedido #' + id + ' → ' + e.target.value);
        } catch (err) { toast(err.message, 'error'); }
        cargarPedidos(); cargarProductos().catch(() => {}); stats();
    });

    // ---------- Pestanas ----------
    function pestana(pedidos) {
        $('tab-productos').classList.toggle('activa', !pedidos);
        $('tab-pedidos').classList.toggle('activa', pedidos);
        $('vista-productos').classList.toggle('oculto', pedidos);
        $('vista-pedidos').classList.toggle('oculto', !pedidos);
        if (pedidos) cargarPedidos().catch(err => toast(err.message, 'error'));
    }
    $('tab-productos').addEventListener('click', () => pestana(false));
    $('tab-pedidos').addEventListener('click', () => pestana(true));

    try { await Promise.all([stats(), cargarProductos()]); }
    catch (err) { toast(err.message, 'error'); }
})();
