'use strict';

(async function () {
    await ICE.ready;
    const cont = document.getElementById('contenido');

    function render() {
        const c = ICE.cart;
        if (!c || c.lines.length === 0) {
            cont.innerHTML = '<div class="panel estadovacio"><h3>Tu carrito está vacío</h3><p>Descubre los lanzamientos más exclusivos.</p><br><a class="botonnegro" href="catalogo.html">Ver catálogo</a></div>';
            return;
        }
        const lineas = c.lines.map(l => `
            <div class="lineacarrito">
                <a href="producto.html?slug=${encodeURIComponent(l.slug)}"><img src="${esc(l.image)}" alt="${esc(l.name)}"></a>
                <div class="datos">
                    <a href="producto.html?slug=${encodeURIComponent(l.slug)}">${esc(l.name)}</a>
                    <p>Talla ${esc(l.size)} MX · ${money(l.unitPrice)} c/u</p>
                    <button class="quitar" data-quitar="${l.productId}|${esc(l.size)}">Quitar</button>
                </div>
                <div class="cantidad">
                    <button data-cambia="${l.productId}|${esc(l.size)}|${l.quantity - 1}" aria-label="Menos">−</button>
                    <span>${l.quantity}</span>
                    <button data-cambia="${l.productId}|${esc(l.size)}|${l.quantity + 1}" aria-label="Más">+</button>
                </div>
                <div class="importe">${money(l.lineTotal)}</div>
            </div>`).join('');
        const cupon = c.coupon
            ? '<div class="cuponactivo"><span>Cupón ' + esc(c.coupon) + ' aplicado</span><button id="quitarcupon">Quitar</button></div>'
            : '<div class="cupon"><input id="codigo" placeholder="Código de cupón" maxlength="20"><button class="botonsecundario" id="aplicar">Aplicar</button></div>';
        cont.innerHTML = `
            <div class="doscolumnas">
                <div class="columnaprincipal"><div class="panel">${lineas}</div>
                    <p style="margin-top:14px"><button class="quitar" id="vaciar">Vaciar carrito</button></p></div>
                <aside class="panel resumenpanel">
                    <h3>Resumen</h3>
                    ${cupon}
                    ${resumenHtml(c)}
                    <br><a class="botonnegro" style="display:block;text-align:center" href="checkout.html">Continuar con la compra</a>
                    <p class="pista">Cupones de prueba: <b>ICE10</b> (10%) y <b>BIENVENIDO</b> (5%).</p>
                </aside>
            </div>`;
    }

    async function run(fn) {
        try { setCart(await fn()); render(); } catch (e) { toast(e.message, 'error'); }
    }

    cont.addEventListener('click', e => {
        const t = e.target;
        if (t.dataset.cambia) {
            const [id, size, q] = t.dataset.cambia.split('|');
            run(() => api('/cart/items', { method: 'PUT', body: { productId: Number(id), size, quantity: Number(q) } }));
        } else if (t.dataset.quitar) {
            const [id, size] = t.dataset.quitar.split('|');
            run(() => api('/cart/items?productId=' + id + '&size=' + encodeURIComponent(size), { method: 'DELETE' }));
        } else if (t.id === 'vaciar') {
            run(() => api('/cart', { method: 'DELETE' }));
        } else if (t.id === 'aplicar') {
            const code = document.getElementById('codigo').value.trim();
            if (code) run(() => api('/cart/coupon', { method: 'POST', body: { code } }));
        } else if (t.id === 'quitarcupon') {
            run(() => api('/cart/coupon', { method: 'DELETE' }));
        }
    });

    render();
})();
