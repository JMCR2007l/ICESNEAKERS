package com.icesneakers.dto;

import com.icesneakers.model.Enums;
import jakarta.validation.constraints.*;
import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;

/** Todos los objetos de entrada/salida de la API REST. */
public final class Dtos {
    private Dtos() {}

    // ---------- Productos ----------
    public record ProductDto(Long id, String slug, String name, String detail, String description,
                             BigDecimal price, BigDecimal oldPrice, String image, Enums.Gender gender,
                             boolean featured, int stock, List<String> sizes, boolean onSale) {}

    public record ProductRequest(
            @NotBlank(message = "El nombre es obligatorio") @Size(max = 120) String name,
            @Size(max = 120) String detail,
            @Size(max = 1000) String description,
            @NotNull(message = "El precio es obligatorio") @DecimalMin(value = "0.01", message = "El precio debe ser mayor a 0") BigDecimal price,
            @DecimalMin(value = "0.01", message = "El precio anterior debe ser mayor a 0") BigDecimal oldPrice,
            @Pattern(regexp = "^imagenes/[\\w\\-./]+$", message = "La imagen debe ser una ruta dentro de imagenes/") String image,
            @NotNull(message = "El genero es obligatorio") Enums.Gender gender,
            boolean featured,
            @Min(value = 0, message = "El stock no puede ser negativo") int stock,
            @NotEmpty(message = "Agrega al menos una talla") List<@Pattern(regexp = "^\\d{2}(\\.5)?$", message = "Talla invalida (ej. 26 o 26.5)") String> sizes) {}

    public record PageResponse<T>(List<T> items, int page, int totalPages, long total) {}

    // ---------- Autenticacion ----------
    public record RegisterRequest(
            @NotBlank(message = "El nombre es obligatorio") @Size(max = 80) String name,
            @NotBlank(message = "El correo es obligatorio") @Email(message = "Correo invalido") String email,
            @NotBlank @Size(min = 8, max = 72, message = "La contrasena debe tener entre 8 y 72 caracteres") String password) {}

    public record LoginRequest(@NotBlank(message = "El correo es obligatorio") String email,
                               @NotBlank(message = "La contrasena es obligatoria") String password) {}

    public record UserDto(Long id, String name, String email, Enums.Role role) {}

    public record MeResponse(UserDto user) {}

    // ---------- Carrito ----------
    public record CartItemRequest(@NotNull Long productId, @NotBlank String size, @Min(0) @Max(10) int quantity) {}

    public record CouponRequest(@NotBlank(message = "Escribe un cupon") String code) {}

    public record CartLineView(Long productId, String slug, String name, String image, String size,
                               int quantity, BigDecimal unitPrice, BigDecimal lineTotal, int stock) {}

    public record CartView(List<CartLineView> lines, int itemCount, BigDecimal subtotal, BigDecimal discount,
                           BigDecimal shipping, BigDecimal total, String coupon,
                           BigDecimal freeShippingThreshold, BigDecimal missingForFreeShipping) {}

    // ---------- Pedidos ----------
    public record CheckoutRequest(
            @NotBlank(message = "El nombre es obligatorio") @Size(max = 120) String fullName,
            @NotBlank(message = "El telefono es obligatorio") @Pattern(regexp = "^[0-9 +()\\-]{8,20}$", message = "Telefono invalido") String phone,
            @NotBlank(message = "La calle es obligatoria") @Size(max = 160) String street,
            @NotBlank(message = "La ciudad es obligatoria") @Size(max = 80) String city,
            @NotBlank(message = "El estado es obligatorio") @Size(max = 80) String state,
            @NotBlank @Pattern(regexp = "^\\d{5}$", message = "El codigo postal debe tener 5 digitos") String zip,
            @NotBlank @Pattern(regexp = "^(TARJETA|OXXO|TRANSFERENCIA)$", message = "Metodo de pago invalido") String paymentMethod) {}

    public record OrderItemDto(Long productId, String name, String image, String size, int quantity,
                               BigDecimal unitPrice, BigDecimal lineTotal) {}

    public record OrderDto(Long id, Instant createdAt, Enums.OrderStatus status, BigDecimal subtotal,
                           BigDecimal discount, BigDecimal shipping, BigDecimal total, String couponCode,
                           String paymentMethod, String customerName, String customerEmail,
                           String address, List<OrderItemDto> items) {}

    public record StatusRequest(@NotNull Enums.OrderStatus status) {}

    // ---------- Administracion ----------
    public record StatsDto(long orders, BigDecimal revenue, long products, long users, List<ProductDto> lowStock) {}
}
