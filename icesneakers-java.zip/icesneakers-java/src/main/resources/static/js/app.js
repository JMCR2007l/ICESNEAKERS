/* Utilidades compartidas: API, cabecera/pie, carrito, avisos. */
'use strict';

const ICE = { user: null, cart: null };

async function api(path, { method = 'GET', body } = {}) {
    const res = await fetch('/api' + path, {
        method,
        headers: body !== undefined ? { 'Content-Type': 'application/json' } : {},
        body: body !== undefined ? JSON.stringify(body) : undefined,
        credentials: 'same-origin'
    });
    const text = await res.text();
    let data = null;
    if (text) { try { data = JSON.parse(text); } catch (e) { data = null; } }
    if (!res.ok) {
        const err = new Error((data && data.error) || 'Error ' + res.status);
        err.status = res.status;
        throw err;
    }
    return data;
}

function esc(v) {
    return String(v ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

function money(n) {
    return '$' + Number(n).toLocaleString('es-MX', { minimumFractionDigits: 0, maximumFractionDigits: 2 });
}

function toast(msg, tipo) {
    let box = document.getElementById('toasts');
    if (!box) { box = document.createElement('div'); box.id = 'toasts'; document.body.appendChild(box); }
    const t = document.createElement('div');
    t.className = 'toast' + (tipo === 'error' ? ' error' : '');
    t.textContent = msg;
    box.appendChild(t);
    setTimeout(() => t.remove(), 3200);
}

function params() { return new URLSearchParams(location.search); }

/** Solo se permite volver a paginas internas simples (evita redirecciones abiertas). */
function safeNext(v, fallback) { return /^[a-z0-9\-]+\.html(\?[\w=&%\-]*)?$/i.test(v || '') ? v : fallback; }

function productCard(p) {
    const agotado = p.stock <= 0;
    const etiqueta = agotado ? '<span class="etiqueta agotado">Agotado</span>'
        : p.onSale ? '<span class="etiqueta">Oferta</span>'
        : p.stock <= 5 ? '<span class="etiqueta pocas">Últimas ' + p.stock + '</span>' : '';
    const viejo = p.oldPrice ? '<small>' + money(p.oldPrice) + '</small>' : '';
    return `
    <article class="cuadroproducto">
        ${etiqueta}
        <div class="cuadrofoto"><a href="producto.html?slug=${encodeURIComponent(p.slug)}"><img src="${esc(p.image)}" alt="Tenis ${esc(p.name)}" loading="lazy"></a></div>
        <div class="cuadronombre"><h3><a href="producto.html?slug=${encodeURIComponent(p.slug)}">${esc(p.name)}</a></h3></div>
        <div class="cuadrodetalle"><p>${esc(p.detail)}</p></div>
        <div class="cuadrodescripcion"><p>${esc(p.description)}</p></div>
        <div class="cuadroprecio"><p>${money(p.price)}${viejo}</p></div>
        <div class="cuadrocompra"><a class="botoncompra${agotado ? ' desactivado' : ''}" href="producto.html?slug=${encodeURIComponent(p.slug)}">${agotado ? 'Agotado' : 'Comprar ahora'}</a></div>
    </article>`;
}

function headerHtml(activo) {
    const u = ICE.user;
    const cls = k => (activo === k ? ' class="activo"' : '');
    const cuenta = u
        ? `<span class="nombre-usuario">${esc(u.name.split(' ')[0])}</span><a href="cuenta.html" title="Mi cuenta"><img src="imagenes/perfil.png" alt="Mi cuenta"></a>`
        : `<a href="login.html" title="Iniciar sesión"><img src="imagenes/perfil.png" alt="Iniciar sesión"></a>`;
    const admin = u && u.role === 'ADMIN' ? `<li><a href="admin.html"${cls('admin')}>Admin</a></li>` : '';
    return `
        <div class="logo"><a href="index.html"><img src="imagenes/logo-ice.png" alt="ICE sneakers"></a></div>
        <nav id="nav">
            <ul>
                <li><a href="catalogo.html?genero=HOMBRE"${cls('HOMBRE')}>Hombre</a></li>
                <li><a href="catalogo.html?genero=MUJER"${cls('MUJER')}>Mujer</a></li>
                <li><a href="catalogo.html?genero=NINOS"${cls('NINOS')}>Niños</a></li>
                <li><a href="index.html#productosdestacados">Destacados</a></li>
                <li><a href="catalogo.html?oferta=1"${cls('oferta')}>Ofertas</a></li>
                <li><a href="catalogo.html"${cls('catalogo')}>Catálogo</a></li>
                ${admin}
            </ul>
        </nav>
        <form class="search" id="formbuscar" role="search">
            <input type="text" id="buscar" placeholder="Buscar" aria-label="Buscar" autocomplete="off">
            <button type="submit" aria-label="Buscar"><img src="imagenes/buscar.png" alt=""></button>
        </form>
        <div class="iconos">
            ${cuenta}
            <a href="carrito.html" title="Carrito"><img src="imagenes/carrito.png" alt="Carrito"><span class="insignia oculto" id="insignia">0</span></a>
            <button id="btnmenu" aria-label="Menú"><img src="imagenes/barras.png" alt=""></button>
        </div>`;
}

const FOOTER_HTML = `
    <div class="cuadrocolumna"><h4>TIENDA</h4><ul>
        <li><a href="catalogo.html?orden=nuevo">Novedades</a></li>
        <li><a href="catalogo.html">Zapatillas</a></li>
        <li><a href="catalogo.html?oferta=1">Outlet</a></li>
        <li><a href="catalogo.html">Marcas</a></li></ul></div>
    <div class="cuadrocolumna"><h4>AYUDA</h4><ul>
        <li><a href="carrito.html">Cómo comprar</a></li>
        <li><a href="cuenta.html">Seguimiento de pedido</a></li>
        <li><a href="#">Envíos (gratis desde $10,000)</a></li>
        <li><a href="#">Devoluciones</a></li>
        <li><a href="#">Contacto</a></li></ul></div>
    <div class="cuadrocolumna"><h4>INFORMACIÓN</h4><ul>
        <li><a href="index.html">Sobre ICEsneakers</a></li>
        <li><a href="#">Aviso legal</a></li>
        <li><a href="#">Política de privacidad</a></li>
        <li><a href="#">Términos y condiciones</a></li>
        <li><a href="#">Cookies</a></li></ul></div>
    <div class="cuadrocolumna"><h4>SÍGUENOS</h4><ul>
        <li><img src="imagenes/facebook.png" alt=""><a href="https://www.facebook.com" target="_blank" rel="noopener">Facebook</a></li>
        <li><img src="imagenes/x.png" alt=""><a href="https://www.x.com" target="_blank" rel="noopener">X</a></li>
        <li><img src="imagenes/instagram.jpg" alt=""><a href="https://www.instagram.com" target="_blank" rel="noopener">Instagram</a></li></ul></div>
    <div class="cuadrocopyright"><p>© 2026 icesneakers</p></div>`;

/** Resumen reutilizado por carrito y checkout. */
function resumenHtml(c) {
    const pct = Math.min(100, Math.floor((1 - Number(c.missingForFreeShipping) / Number(c.freeShippingThreshold)) * 100));
    return `
        <div class="fila"><span>Subtotal (${c.itemCount} ${c.itemCount === 1 ? 'pieza' : 'piezas'})</span><span>${money(c.subtotal)}</span></div>
        ${Number(c.discount) > 0 ? '<div class="fila"><span>Descuento ' + esc(c.coupon) + '</span><span class="verde">−' + money(c.discount) + '</span></div>' : ''}
        <div class="fila"><span>Envío</span><span>${Number(c.shipping) === 0 ? '<span class="verde">Gratis</span>' : money(c.shipping)}</span></div>
        <div class="barraenvio"><div style="width:${pct}%"></div></div>
        <p class="notaenvio">${Number(c.missingForFreeShipping) > 0 ? 'Te faltan ' + money(c.missingForFreeShipping) + ' para envío gratis' : '¡Tienes envío gratis!'}</p>
        <div class="fila total"><span>Total</span><span>${money(c.total)}</span></div>`;
}

function updateBadge() {
    const b = document.getElementById('insignia');
    if (!b) return;
    const n = ICE.cart ? ICE.cart.itemCount : 0;
    b.textContent = n;
    b.classList.toggle('oculto', n === 0);
}

function setCart(cart) { ICE.cart = cart; updateBadge(); }

/** Inicializa sesion + carrito y pinta cabecera y pie. Cada pagina espera a ICE.ready. */
ICE.ready = (async function () {
    try {
        const [me, cart] = await Promise.all([api('/auth/me'), api('/cart')]);
        ICE.user = me.user;
        ICE.cart = cart;
    } catch (e) { /* sin backend: la pagina sigue mostrando contenido estatico */ }
    if (document.readyState === 'loading') {
        await new Promise(r => document.addEventListener('DOMContentLoaded', r));
    }
    const h = document.querySelector('header');
    if (h) {
        const p = params();
        const pag = document.body.dataset.pagina || '';
        const activo = pag === 'catalogo' ? (p.get('genero') || (p.get('oferta') ? 'oferta' : 'catalogo')) : pag;
        h.innerHTML = headerHtml(activo);
        document.getElementById('btnmenu').addEventListener('click', () => document.getElementById('nav').classList.toggle('abierto'));
        const inp = document.getElementById('buscar');
        if (pag === 'catalogo' && p.get('q')) inp.value = p.get('q');
        document.getElementById('formbuscar').addEventListener('submit', ev => {
            ev.preventDefault();
            const q = inp.value.trim();
            location.href = 'catalogo.html' + (q ? '?q=' + encodeURIComponent(q) : '');
        });
    }
    const f = document.getElementById('contenedorpie');
    if (f) f.innerHTML = FOOTER_HTML;
    updateBadge();
})();
