package com.icesneakers.service;

import com.icesneakers.dto.Dtos.*;
import com.icesneakers.model.Enums;
import com.icesneakers.model.Product;
import com.icesneakers.repo.ProductRepository;
import jakarta.persistence.criteria.Predicate;
import java.math.BigDecimal;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ProductService {

    private final ProductRepository repo;

    public ProductService(ProductRepository repo) {
        this.repo = repo;
    }

    public static ProductDto toDto(Product p) {
        return new ProductDto(p.getId(), p.getSlug(), p.getName(), p.getDetail(), p.getDescription(),
                p.getPrice(), p.getOldPrice(), p.getImage(), p.getGender(), p.isFeatured(), p.getStock(),
                p.sizeList(), p.getOldPrice() != null);
    }

    @Transactional(readOnly = true)
    public PageResponse<ProductDto> search(String q, Enums.Gender gender, BigDecimal min, BigDecimal max,
                                           boolean onSale, boolean featured, String order, int page, int size) {
        Specification<Product> spec = (root, query, cb) -> {
            List<Predicate> ps = new ArrayList<>();
            if (q != null && !q.isBlank()) {
                String like = "%" + q.trim().toLowerCase(Locale.ROOT) + "%";
                ps.add(cb.or(
                        cb.like(cb.lower(root.get("name")), like),
                        cb.like(cb.lower(root.get("detail")), like),
                        cb.like(cb.lower(root.get("description")), like)));
            }
            if (gender != null) {
                ps.add(cb.or(cb.equal(root.get("gender"), gender), cb.equal(root.get("gender"), Enums.Gender.UNISEX)));
            }
            if (min != null) ps.add(cb.greaterThanOrEqualTo(root.get("price"), min));
            if (max != null) ps.add(cb.lessThanOrEqualTo(root.get("price"), max));
            if (onSale) ps.add(cb.isNotNull(root.get("oldPrice")));
            if (featured) ps.add(cb.isTrue(root.get("featured")));
            return cb.and(ps.toArray(new Predicate[0]));
        };

        Sort sort = switch (order == null ? "" : order) {
            case "precio_asc" -> Sort.by(Sort.Order.asc("price"), Sort.Order.asc("id"));
            case "precio_desc" -> Sort.by(Sort.Order.desc("price"), Sort.Order.asc("id"));
            case "nuevo" -> Sort.by(Sort.Order.desc("createdAt"), Sort.Order.desc("id"));
            default -> Sort.by(Sort.Order.desc("featured"), Sort.Order.asc("id"));
        };

        int safeSize = Math.min(Math.max(size, 1), 48);
        Page<Product> result = repo.findAll(spec, PageRequest.of(Math.max(page, 0), safeSize, sort));
        return new PageResponse<>(result.getContent().stream().map(ProductService::toDto).toList(),
                result.getNumber(), result.getTotalPages(), result.getTotalElements());
    }

    @Transactional(readOnly = true)
    public ProductDto getBySlug(String slug) {
        return toDto(repo.findBySlug(slug).orElseThrow(() -> ApiException.notFound("Producto no encontrado")));
    }

    @Transactional(readOnly = true)
    public List<ProductDto> related(String slug) {
        Product p = repo.findBySlug(slug).orElseThrow(() -> ApiException.notFound("Producto no encontrado"));
        return repo.findTop4ByIdNotOrderByFeaturedDescIdAsc(p.getId()).stream().map(ProductService::toDto).toList();
    }

    @Transactional(readOnly = true)
    public List<ProductDto> all() {
        return repo.findAll(Sort.by("id")).stream().map(ProductService::toDto).toList();
    }

    @Transactional
    public ProductDto create(ProductRequest r) {
        Product p = new Product();
        p.setSlug(uniqueSlug(slugify(r.name()), null));
        apply(p, r);
        return toDto(repo.save(p));
    }

    @Transactional
    public ProductDto update(Long id, ProductRequest r) {
        Product p = repo.findById(id).orElseThrow(() -> ApiException.notFound("Producto no encontrado"));
        apply(p, r);
        return toDto(repo.save(p));
    }

    @Transactional
    public void delete(Long id) {
        if (!repo.existsById(id)) throw ApiException.notFound("Producto no encontrado");
        repo.deleteById(id);
    }

    private void apply(Product p, ProductRequest r) {
        if (r.oldPrice() != null && r.oldPrice().compareTo(r.price()) <= 0) {
            throw new ApiException(HttpStatus.BAD_REQUEST, "El precio anterior debe ser mayor al precio actual");
        }
        p.setName(r.name().trim());
        p.setDetail(r.detail() == null ? null : r.detail().trim());
        p.setDescription(r.description() == null ? null : r.description().trim());
        p.setPrice(r.price());
        p.setOldPrice(r.oldPrice());
        p.setImage(r.image());
        p.setGender(r.gender());
        p.setFeatured(r.featured());
        p.setStock(r.stock());
        p.setSizes(String.join(",", r.sizes()));
    }

    public static String slugify(String name) {
        String s = Normalizer.normalize(name, Normalizer.Form.NFD).replaceAll("\\p{M}", "");
        s = s.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+", "-").replaceAll("(^-|-$)", "");
        return s.isEmpty() ? "producto" : s;
    }

    private String uniqueSlug(String base, Long ignoreId) {
        String slug = base;
        int n = 2;
        while (repo.existsBySlug(slug)) {
            slug = base + "-" + n++;
        }
        return slug;
    }
}
