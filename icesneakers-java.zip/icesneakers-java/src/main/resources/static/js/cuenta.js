'use strict';

(async function () {
    await ICE.ready;
    if (!ICE.user) { location.replace('login.html?next=cuenta.html'); return; }
    const $ = id => document.getElementById(id);
    $('perfil').innerHTML = '<b>' + esc(ICE.user.name) + '</b><br>' + esc(ICE.user.email)
        + (ICE.user.role === 'ADMIN' ? '<br><a href="admin.html"><b>Ir al panel de administración →</b></a>' : '');

    $('salir').addEventListener('click', async () => {
        try { await api('/auth/logout', { method: 'POST' }); } finally { location.href = 'index.html'; }
    });

    async function cargar() {
        try {
            const os = await api('/orders');
            $('pedidos').innerHTML = os.length
                ? os.map(o => pedidoHtml(o, {
                    extra: (o.status === 'PENDIENTE' || o.status === 'PAGADO')
                        ? '<p style="margin-top:10px"><button class="botonsecundario" data-cancelar="' + o.id + '">Cancelar pedido</button></p>' : ''
                })).join('')
                : '<div class="estadovacio"><h3>Aún no tienes pedidos</h3><a class="botonnegro" href="catalogo.html">Ir al catálogo</a></div>';
        } catch (e) { $('pedidos').innerHTML = '<p class="mensaje error">' + esc(e.message) + '</p>'; }
    }

    $('pedidos').addEventListener('click', async e => {
        const id = e.target.dataset.cancelar;
        if (!id || !confirm('¿Cancelar el pedido #' + id + '?')) return;
        try { await api('/orders/' + id + '/cancel', { method: 'POST' }); toast('Pedido cancelado'); cargar(); }
        catch (err) { toast(err.message, 'error'); }
    });
    cargar();
})();
