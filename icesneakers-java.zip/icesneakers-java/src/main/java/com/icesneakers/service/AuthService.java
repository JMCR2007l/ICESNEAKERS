package com.icesneakers.service;

import com.icesneakers.dto.Dtos.*;
import com.icesneakers.model.AppUser;
import com.icesneakers.model.Enums;
import com.icesneakers.repo.UserRepository;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import java.time.Instant;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AuthService {

    static final String SESSION_USER = "uid";
    private static final int MAX_FAILS = 5;
    private static final long LOCK_SECONDS = 60;

    private record Attempts(int fails, Instant lockedUntil) {}

    private final UserRepository users;
    private final BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
    private final Map<String, Attempts> throttle = new ConcurrentHashMap<>();

    public AuthService(UserRepository users) {
        this.users = users;
    }

    public static UserDto toDto(AppUser u) {
        return new UserDto(u.getId(), u.getName(), u.getEmail(), u.getRole());
    }

    public AppUser createUser(String name, String email, String rawPassword, Enums.Role role) {
        AppUser u = new AppUser();
        u.setName(name.trim());
        u.setEmail(email.trim().toLowerCase(Locale.ROOT));
        u.setPasswordHash(encoder.encode(rawPassword));
        u.setRole(role);
        return users.save(u);
    }

    public UserDto register(RegisterRequest r, HttpServletRequest req) {
        String email = r.email().trim().toLowerCase(Locale.ROOT);
        if (users.existsByEmail(email)) throw ApiException.conflict("Ese correo ya esta registrado");
        AppUser u = createUser(r.name(), email, r.password(), Enums.Role.CLIENTE);
        startSession(req, u);
        return toDto(u);
    }

    public UserDto login(LoginRequest r, HttpServletRequest req) {
        String email = r.email().trim().toLowerCase(Locale.ROOT);
        Attempts a = throttle.get(email);
        if (a != null && a.lockedUntil() != null && a.lockedUntil().isAfter(Instant.now())) {
            throw new ApiException(org.springframework.http.HttpStatus.TOO_MANY_REQUESTS,
                    "Demasiados intentos. Espera un minuto e intenta de nuevo.");
        }
        AppUser u = users.findByEmail(email).orElse(null);
        if (u == null || !encoder.matches(r.password(), u.getPasswordHash())) {
            int fails = (a == null ? 0 : a.fails()) + 1;
            throttle.put(email, new Attempts(fails, fails >= MAX_FAILS ? Instant.now().plusSeconds(LOCK_SECONDS) : null));
            throw ApiException.unauthorized("Correo o contrasena incorrectos");
        }
        throttle.remove(email);
        startSession(req, u);
        return toDto(u);
    }

    public void logout(HttpServletRequest req) {
        HttpSession s = req.getSession(false);
        if (s != null) s.invalidate();
    }

    private void startSession(HttpServletRequest req, AppUser u) {
        HttpSession s = req.getSession(true);
        req.changeSessionId(); // evita fijacion de sesion; conserva el carrito
        s.setAttribute(SESSION_USER, u.getId());
    }

    /** Usuario de la sesion o null. */
    public AppUser currentUser(HttpSession session) {
        if (session == null) return null;
        Object id = session.getAttribute(SESSION_USER);
        return id instanceof Long l ? users.findById(l).orElse(null) : null;
    }

    public AppUser requireUser(HttpSession session) {
        AppUser u = currentUser(session);
        if (u == null) throw ApiException.unauthorized("Inicia sesion para continuar");
        return u;
    }

    public AppUser requireAdmin(HttpSession session) {
        AppUser u = requireUser(session);
        if (u.getRole() != Enums.Role.ADMIN) throw ApiException.forbidden("Solo administradores");
        return u;
    }
}
