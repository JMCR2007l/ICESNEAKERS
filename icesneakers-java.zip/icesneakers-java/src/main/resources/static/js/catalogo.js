'use strict';
(async function () {
    await ICE.ready;
    const $ = id => document.getElementById(id);
    const p = params();
    const PAGE = 12;
    let page = 0;

    $('f-genero').value = p.get('genero') || '';
    $('f-min').value = p.get('min') || '';
    $('f-max').value = p.get('max') || '';
    $('f-orden').value = p.get('orden') || '';
    $('f-oferta').checked = !!p.get('oferta');

    function query() {
        const q = new URLSearchParams();
        if (p.get('q')) q.set('q', p.get('q'));
        if ($('f-genero').value) q.set('genero', $('f-genero').value);
        if ($('f-min').value) q.set('min', $('f-min').value);
        if ($('f-max').value) q.set('max', $('f-max').value);
        if ($('f-orden').value) q.set('orden', $('f-orden').value);
        if ($('f-oferta').checked) q.set('oferta', 'true');
        return q;
    }

    function syncUrl() {
        const q = query();
        if (q.get('oferta')) { q.delete('oferta'); q.set('oferta', '1'); }
        history.replaceState(null, '', 'catalogo.html' + (q.toString() ? '?' + q : ''));
        p.forEach((_, k) => p.delete(k));
        q.forEach((v, k) => p.set(k, v));
    }

    function titulo() {
        const g = { HOMBRE: 'Hombre', MUJER: 'Mujer', NINOS: 'Niños' }[$('f-genero').value];
        let t = g ? 'Catálogo · ' + g : 'Catálogo';
        if ($('f-oferta').checked) t = 'Ofertas' + (g ? ' · ' + g : '');
        if (p.get('q')) t = 'Resultados';
        $('titulo').textContent = t;
    }

    async function load(reset) {
        if (reset) { page = 0; $('lista').innerHTML = '<p class="cargando">Cargando…</p>'; }
        const q = query();
        q.set('page', page);
        q.set('size', PAGE);
        if ($('f-oferta').checked) q.set('oferta', 'true');
        try {
            const r = await api('/products?' + q);
            const html = r.items.map(productCard).join('');
            if (reset) $('lista').innerHTML = '';
            if (reset && r.items.length === 0) {
                $('lista').innerHTML = '<div class="estadovacio" style="grid-column:1/-1"><h3>No encontramos tenis con esos filtros</h3><p>Prueba quitando algún filtro o buscando otra cosa.</p></div>';
            } else {
                $('lista').insertAdjacentHTML('beforeend', html);
            }
            const shown = $('lista').querySelectorAll('.cuadroproducto').length;
            $('resumen').textContent = r.total + (r.total === 1 ? ' resultado' : ' resultados')
                + (p.get('q') ? ' para «' + p.get('q') + '»' : '');
            $('mas').classList.toggle('oculto', r.page + 1 >= r.totalPages);
        } catch (e) {
            $('lista').innerHTML = '<div class="estadovacio" style="grid-column:1/-1"><h3>Error al cargar</h3><p>' + esc(e.message) + '</p></div>';
        }
    }

    function refresh() { syncUrl(); titulo(); load(true); }

    ['f-genero', 'f-orden', 'f-oferta'].forEach(id => $(id).addEventListener('change', refresh));
    ['f-min', 'f-max'].forEach(id => $(id).addEventListener('change', refresh));
    $('filtros').addEventListener('submit', e => e.preventDefault());
    $('limpiar').addEventListener('click', () => {
        $('filtros').reset();
        p.delete('q');
        $('buscar') && ($('buscar').value = '');
        refresh();
    });
    $('mas').addEventListener('click', () => { page++; load(false); });

    titulo();
    load(true);
})();
