'use strict';
(async function () {
    await ICE.ready;
    const slug = params().get('slug');
    const cont = document.getElementById('pagina');
    if (!slug) { cont.innerHTML = '<div class="estadovacio"><h3>Producto no especificado</h3><a class="botonnegro" href="catalogo.html">Ver catálogo</a></div>'; return; }

    let p;
    try { p = await api('/products/' + encodeURIComponent(slug)); }
    catch (e) {
        cont.innerHTML = '<div class="estadovacio"><h3>' + (e.status === 404 ? 'Ese producto no existe' : 'Error al cargar') + '</h3><p>' + esc(e.message) + '</p><br><a class="botonnegro" href="catalogo.html">Ver catálogo</a></div>';
        return;
    }
    document.title = 'ICE sneakers - ' + p.name;

    let talla = null, cant = 1;
    const agotado = p.stock <= 0;
    const ahorro = p.oldPrice ? Math.round((1 - p.price / p.oldPrice) * 100) : 0;
    const maxCant = Math.min(10, p.stock);

    cont.innerHTML = `
        <div class="migas"><a href="index.html">Inicio</a> / <a href="catalogo.html">Catálogo</a> / ${esc(p.name)}</div>
        <div class="fichaproducto">
            <div class="fichafoto">
                ${p.onSale ? '<span class="etiqueta">Oferta</span>' : ''}
                <img src="${esc(p.image)}" alt="Tenis ${esc(p.name)}">
            </div>
            <div class="fichainfo">
                <h1>${esc(p.name)}</h1>
                <p class="colab">${esc(p.detail)}</p>
                <p class="desc">${esc(p.description)}</p>
                <p class="precio">${money(p.price)}${p.oldPrice ? '<small>' + money(p.oldPrice) + '</small>' : ''}</p>
                ${ahorro ? '<p class="ahorro">Ahorras ' + ahorro + '% (' + money(p.oldPrice - p.price) + ')</p>' : ''}
                <h4>Talla (MX)</h4>
                <div class="tallas" id="tallas">${p.sizes.map(s => '<button type="button" class="talla" data-t="' + esc(s) + '">' + esc(s) + '</button>').join('')}</div>
                <h4>Cantidad</h4>
                <div class="cantidad"><button type="button" id="menos" aria-label="Menos">−</button><span id="cant">1</span><button type="button" id="mas" aria-label="Más">+</button></div>
                <p class="stockinfo ${p.stock <= 5 ? 'bajo' : ''}">${agotado ? 'Agotado por ahora' : p.stock <= 5 ? '¡Solo quedan ' + p.stock + ' piezas!' : p.stock + ' piezas disponibles'}</p>
                <div class="acciones">
                    <button class="botonnegro" id="agregar" ${agotado ? 'disabled' : ''}>Agregar al carrito</button>
                    <button class="botonsecundario" id="comprar" ${agotado ? 'disabled' : ''}>Comprar ahora</button>
                </div>
            </div>
        </div>
        <section class="seccionrelacionados"><h2>También te puede gustar</h2><div id="relacionados" class="grillaproductos"></div></section>`;

    const $ = id => document.getElementById(id);
    $('tallas').addEventListener('click', e => {
        const b = e.target.closest('.talla'); if (!b) return;
        talla = b.dataset.t;
        $('tallas').querySelectorAll('.talla').forEach(x => x.classList.toggle('activa', x === b));
    });
    $('menos').addEventListener('click', () => { cant = Math.max(1, cant - 1); $('cant').textContent = cant; });
    $('mas').addEventListener('click', () => { cant = Math.min(maxCant, cant + 1); $('cant').textContent = cant; });

    async function agregar() {
        if (!talla) { toast('Elige una talla primero', 'error'); return false; }
        try {
            setCart(await api('/cart/items', { method: 'POST', body: { productId: p.id, size: talla, quantity: cant } }));
            return true;
        } catch (e) { toast(e.message, 'error'); return false; }
    }
    $('agregar').addEventListener('click', async () => { if (await agregar()) toast('Agregado al carrito ✓'); });
    $('comprar').addEventListener('click', async () => { if (await agregar()) location.href = 'carrito.html'; });

    try {
        const rel = await api('/products/' + encodeURIComponent(slug) + '/related');
        $('relacionados').innerHTML = rel.map(productCard).join('');
    } catch (e) { /* opcional */ }
})();
