package com.icesneakers.web;

import com.icesneakers.dto.Dtos.*;
import com.icesneakers.service.CartService;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/cart")
public class CartController {

    private final CartService cart;

    public CartController(CartService cart) {
        this.cart = cart;
    }

    @GetMapping
    public CartView get(HttpSession s) {
        return cart.view(s);
    }

    @PostMapping("/items")
    public CartView add(@Valid @RequestBody CartItemRequest r, HttpSession s) {
        return cart.add(s, r);
    }

    @PutMapping("/items")
    public CartView setQuantity(@Valid @RequestBody CartItemRequest r, HttpSession s) {
        return cart.setQuantity(s, r);
    }

    @DeleteMapping("/items")
    public CartView remove(@RequestParam long productId, @RequestParam String size, HttpSession s) {
        return cart.remove(s, productId, size);
    }

    @PostMapping("/coupon")
    public CartView coupon(@Valid @RequestBody CouponRequest r, HttpSession s) {
        return cart.applyCoupon(s, r.code());
    }

    @DeleteMapping("/coupon")
    public CartView removeCoupon(HttpSession s) {
        return cart.removeCoupon(s);
    }

    @DeleteMapping
    public CartView clear(HttpSession s) {
        return cart.clear(s);
    }
}
