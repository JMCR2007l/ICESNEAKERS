package com.icesneakers.service;

import com.icesneakers.dto.Dtos.*;
import com.icesneakers.model.Product;
import com.icesneakers.repo.ProductRepository;
import jakarta.servlet.http.HttpSession;
import java.io.Serializable;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import org.springframework.stereotype.Service;

/** Carrito guardado en la sesion HTTP (funciona para invitados y usuarios). */
@Service
public class CartService {

    private static final String KEY = "cart";
    public static final BigDecimal FREE_SHIPPING_FROM = new BigDecimal("10000");
    public static final BigDecimal SHIPPING_FEE = new BigDecimal("199");
    private static final int MAX_PER_LINE = 10;

    /** Cupones disponibles: codigo -> porcentaje de descuento. */
    private static final Map<String, BigDecimal> COUPONS = Map.of(
            "ICE10", new BigDecimal("0.10"),
            "BIENVENIDO", new BigDecimal("0.05"));

    public static class Line implements Serializable {
        long productId;
        String size;
        int quantity;
    }

    public static class Cart implements Serializable {
        final List<Line> lines = new ArrayList<>();
        String coupon;
    }

    private final ProductRepository products;

    public CartService(ProductRepository products) {
        this.products = products;
    }

    private Cart cart(HttpSession s) {
        Cart c = (Cart) s.getAttribute(KEY);
        if (c == null) {
            c = new Cart();
            s.setAttribute(KEY, c);
        }
        return c;
    }

    public CartView view(HttpSession s) {
        Cart c = cart(s);
        List<CartLineView> views = new ArrayList<>();
        List<Line> stale = new ArrayList<>();
        BigDecimal subtotal = BigDecimal.ZERO;
        int count = 0;
        for (Line l : c.lines) {
            Product p = products.findById(l.productId).orElse(null);
            if (p == null) { stale.add(l); continue; }
            BigDecimal lineTotal = p.getPrice().multiply(BigDecimal.valueOf(l.quantity));
            views.add(new CartLineView(p.getId(), p.getSlug(), p.getName(), p.getImage(), l.size,
                    l.quantity, p.getPrice(), lineTotal, p.getStock()));
            subtotal = subtotal.add(lineTotal);
            count += l.quantity;
        }
        c.lines.removeAll(stale);

        BigDecimal pct = c.coupon == null ? BigDecimal.ZERO : COUPONS.getOrDefault(c.coupon, BigDecimal.ZERO);
        BigDecimal discount = subtotal.multiply(pct).setScale(2, RoundingMode.HALF_UP);
        BigDecimal afterDiscount = subtotal.subtract(discount);
        BigDecimal shipping = (views.isEmpty() || afterDiscount.compareTo(FREE_SHIPPING_FROM) >= 0)
                ? BigDecimal.ZERO : SHIPPING_FEE;
        BigDecimal missing = views.isEmpty() ? FREE_SHIPPING_FROM
                : FREE_SHIPPING_FROM.subtract(afterDiscount).max(BigDecimal.ZERO);
        return new CartView(views, count, subtotal, discount, shipping, afterDiscount.add(shipping),
                c.coupon, FREE_SHIPPING_FROM, missing);
    }

    public CartView add(HttpSession s, CartItemRequest r) {
        if (r.quantity() < 1) throw ApiException.badRequest("La cantidad debe ser al menos 1");
        Product p = products.findById(r.productId()).orElseThrow(() -> ApiException.notFound("Producto no encontrado"));
        if (!p.sizeList().contains(r.size())) throw ApiException.badRequest("Talla no disponible");
        Cart c = cart(s);
        Line line = find(c, p.getId(), r.size());
        int newQty = (line == null ? 0 : line.quantity) + r.quantity();
        checkQty(p, newQty);
        if (line == null) {
            line = new Line();
            line.productId = p.getId();
            line.size = r.size();
            c.lines.add(line);
        }
        line.quantity = newQty;
        return view(s);
    }

    /** Fija la cantidad exacta de una linea; 0 la elimina. */
    public CartView setQuantity(HttpSession s, CartItemRequest r) {
        Cart c = cart(s);
        Line line = find(c, r.productId(), r.size());
        if (line == null) throw ApiException.notFound("Ese articulo no esta en tu carrito");
        if (r.quantity() == 0) {
            c.lines.remove(line);
        } else {
            Product p = products.findById(r.productId()).orElseThrow(() -> ApiException.notFound("Producto no encontrado"));
            checkQty(p, r.quantity());
            line.quantity = r.quantity();
        }
        return view(s);
    }

    public CartView remove(HttpSession s, long productId, String size) {
        Cart c = cart(s);
        Line line = find(c, productId, size);
        if (line != null) c.lines.remove(line);
        return view(s);
    }

    public CartView clear(HttpSession s) {
        s.removeAttribute(KEY);
        return view(s);
    }

    public CartView applyCoupon(HttpSession s, String code) {
        String normalized = code.trim().toUpperCase(Locale.ROOT);
        if (!COUPONS.containsKey(normalized)) throw ApiException.badRequest("Cupon invalido");
        cart(s).coupon = normalized;
        return view(s);
    }

    public CartView removeCoupon(HttpSession s) {
        cart(s).coupon = null;
        return view(s);
    }

    private void checkQty(Product p, int qty) {
        if (qty > MAX_PER_LINE) throw ApiException.badRequest("Maximo " + MAX_PER_LINE + " piezas por talla");
        if (qty > p.getStock()) throw ApiException.conflict("Solo quedan " + p.getStock() + " piezas de " + p.getName());
    }

    private Line find(Cart c, long productId, String size) {
        return c.lines.stream().filter(l -> l.productId == productId && l.size.equals(size)).findFirst().orElse(null);
    }
}
