'use strict';

function pedidoHtml(o, opts) {
    opts = opts || {};
    const fecha = new Date(o.createdAt).toLocaleString('es-MX', { dateStyle: 'medium', timeStyle: 'short' });
    const lineas = o.items.map(i => `<li><span>${esc(i.name)} · T${esc(i.size)} × ${i.quantity}</span><span>${money(i.lineTotal)}</span></li>`).join('');
    return `
    <div class="pedido">
        <div class="cabecera"><b>Pedido #${o.id}</b><span class="estado ${esc(o.status)}">${esc(o.status)}</span></div>
        <ul>${lineas}</ul>
        <div class="pie">
            <span>${fecha} · ${esc(o.paymentMethod)}${o.couponCode ? ' · cupón ' + esc(o.couponCode) : ''}${opts.admin ? '<br>' + esc(o.customerName) + ' · ' + esc(o.customerEmail) : ''}<br>${esc(o.address)}</span>
            <span><b>Total ${money(o.total)}</b></span>
        </div>
        ${opts.extra || ''}
    </div>`;
}
