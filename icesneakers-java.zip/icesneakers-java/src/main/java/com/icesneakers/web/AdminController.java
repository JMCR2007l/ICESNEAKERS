package com.icesneakers.web;

import com.icesneakers.dto.Dtos.*;
import com.icesneakers.service.AuthService;
import com.icesneakers.service.OrderService;
import com.icesneakers.service.ProductService;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

/** Panel de administracion: todas las rutas exigen rol ADMIN. */
@RestController
@RequestMapping("/api/admin")
public class AdminController {

    private final AuthService auth;
    private final ProductService products;
    private final OrderService orders;

    public AdminController(AuthService auth, ProductService products, OrderService orders) {
        this.auth = auth;
        this.products = products;
        this.orders = orders;
    }

    @GetMapping("/stats")
    public StatsDto stats(HttpSession s) {
        auth.requireAdmin(s);
        return orders.stats();
    }

    @GetMapping("/products")
    public List<ProductDto> products(HttpSession s) {
        auth.requireAdmin(s);
        return products.all();
    }

    @PostMapping("/products")
    @ResponseStatus(HttpStatus.CREATED)
    public ProductDto create(@Valid @RequestBody ProductRequest r, HttpSession s) {
        auth.requireAdmin(s);
        return products.create(r);
    }

    @PutMapping("/products/{id}")
    public ProductDto update(@PathVariable Long id, @Valid @RequestBody ProductRequest r, HttpSession s) {
        auth.requireAdmin(s);
        return products.update(id, r);
    }

    @DeleteMapping("/products/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id, HttpSession s) {
        auth.requireAdmin(s);
        products.delete(id);
    }

    @GetMapping("/orders")
    public List<OrderDto> orders(HttpSession s) {
        auth.requireAdmin(s);
        return orders.all();
    }

    @PatchMapping("/orders/{id}/status")
    public OrderDto status(@PathVariable Long id, @Valid @RequestBody StatusRequest r, HttpSession s) {
        auth.requireAdmin(s);
        return orders.setStatus(id, r.status());
    }
}
