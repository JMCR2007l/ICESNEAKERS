package com.icesneakers;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IceSneakersApplication {

    public static void main(String[] args) {
        SpringApplication.run(IceSneakersApplication.class, args);
    }
}
