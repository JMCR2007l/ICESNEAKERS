package com.icesneakers.service;

import com.icesneakers.dto.Dtos.*;
import com.icesneakers.model.*;
import com.icesneakers.repo.OrderRepository;
import com.icesneakers.repo.ProductRepository;
import com.icesneakers.repo.UserRepository;
import jakarta.servlet.http.HttpSession;
import java.util.List;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class OrderService {

    private final OrderRepository orders;
    private final ProductRepository products;
    private final UserRepository users;
    private final CartService cartService;

    public OrderService(OrderRepository orders, ProductRepository products, UserRepository users, CartService cartService) {
        this.orders = orders;
        this.products = products;
        this.users = users;
        this.cartService = cartService;
    }

    public static OrderDto toDto(CustomerOrder o) {
        List<OrderItemDto> items = o.getItems().stream()
                .map(i -> new OrderItemDto(i.getProductId(), i.getProductName(), i.getImage(), i.getSize(),
                        i.getQuantity(), i.getUnitPrice(),
                        i.getUnitPrice().multiply(java.math.BigDecimal.valueOf(i.getQuantity()))))
                .toList();
        String address = o.getStreet() + ", " + o.getCity() + ", " + o.getState() + " C.P. " + o.getZip();
        return new OrderDto(o.getId(), o.getCreatedAt(), o.getStatus(), o.getSubtotal(), o.getDiscount(),
                o.getShipping(), o.getTotal(), o.getCouponCode(), o.getPaymentMethod(), o.getFullName(),
                o.getUser().getEmail(), address, items);
    }

    /** Convierte el carrito de la sesion en un pedido y descuenta inventario (todo en una transaccion). */
    @Transactional
    public OrderDto checkout(AppUser user, CheckoutRequest r, HttpSession session) {
        CartView cart = cartService.view(session);
        if (cart.lines().isEmpty()) throw ApiException.badRequest("Tu carrito esta vacio");

        CustomerOrder o = new CustomerOrder();
        o.setUser(users.getReferenceById(user.getId()));
        o.setFullName(r.fullName().trim());
        o.setPhone(r.phone().trim());
        o.setStreet(r.street().trim());
        o.setCity(r.city().trim());
        o.setState(r.state().trim());
        o.setZip(r.zip());
        o.setPaymentMethod(r.paymentMethod());
        o.setCouponCode(cart.coupon());
        o.setSubtotal(cart.subtotal());
        o.setDiscount(cart.discount());
        o.setShipping(cart.shipping());
        o.setTotal(cart.total());
        // Tarjeta se considera pagada de inmediato (pago simulado); OXXO/transferencia quedan pendientes.
        o.setStatus("TARJETA".equals(r.paymentMethod()) ? Enums.OrderStatus.PAGADO : Enums.OrderStatus.PENDIENTE);

        for (CartLineView l : cart.lines()) {
            Product p = products.findByIdForUpdate(l.productId())
                    .orElseThrow(() -> ApiException.conflict("Un producto de tu carrito ya no existe"));
            if (p.getStock() < l.quantity()) {
                throw ApiException.conflict("Ya no hay suficiente stock de " + p.getName()
                        + " (quedan " + p.getStock() + ")");
            }
            p.setStock(p.getStock() - l.quantity());
            OrderItem item = new OrderItem();
            item.setProductId(p.getId());
            item.setProductName(p.getName());
            item.setImage(p.getImage());
            item.setSize(l.size());
            item.setQuantity(l.quantity());
            item.setUnitPrice(p.getPrice());
            o.addItem(item);
        }
        CustomerOrder saved = orders.save(o);
        cartService.clear(session);
        return toDto(saved);
    }

    @Transactional(readOnly = true)
    public List<OrderDto> mine(AppUser user) {
        return orders.findByUserOrderByCreatedAtDesc(user).stream().map(OrderService::toDto).toList();
    }

    @Transactional(readOnly = true)
    public OrderDto getMine(AppUser user, Long id) {
        CustomerOrder o = orders.findById(id).orElseThrow(() -> ApiException.notFound("Pedido no encontrado"));
        if (!o.getUser().getId().equals(user.getId())) throw ApiException.notFound("Pedido no encontrado");
        return toDto(o);
    }

    /** El cliente solo puede cancelar mientras el pedido siga pendiente o pagado (aun no enviado). */
    @Transactional
    public OrderDto cancelMine(AppUser user, Long id) {
        CustomerOrder o = orders.findById(id).orElseThrow(() -> ApiException.notFound("Pedido no encontrado"));
        if (!o.getUser().getId().equals(user.getId())) throw ApiException.notFound("Pedido no encontrado");
        if (o.getStatus() != Enums.OrderStatus.PENDIENTE && o.getStatus() != Enums.OrderStatus.PAGADO) {
            throw ApiException.conflict("Este pedido ya no se puede cancelar");
        }
        return toDto(changeStatus(o, Enums.OrderStatus.CANCELADO));
    }

    @Transactional(readOnly = true)
    public List<OrderDto> all() {
        return orders.findAllByOrderByCreatedAtDesc().stream().map(OrderService::toDto).toList();
    }

    @Transactional
    public OrderDto setStatus(Long id, Enums.OrderStatus status) {
        CustomerOrder o = orders.findById(id).orElseThrow(() -> ApiException.notFound("Pedido no encontrado"));
        if (o.getStatus() == Enums.OrderStatus.CANCELADO && status != Enums.OrderStatus.CANCELADO) {
            throw ApiException.conflict("Un pedido cancelado no se puede reactivar");
        }
        return toDto(changeStatus(o, status));
    }

    private CustomerOrder changeStatus(CustomerOrder o, Enums.OrderStatus status) {
        if (status == Enums.OrderStatus.CANCELADO && o.getStatus() != Enums.OrderStatus.CANCELADO) {
            for (OrderItem i : o.getItems()) { // devolver inventario
                products.findByIdForUpdate(i.getProductId()).ifPresent(p -> p.setStock(p.getStock() + i.getQuantity()));
            }
        }
        o.setStatus(status);
        return orders.save(o);
    }

    @Transactional(readOnly = true)
    public StatsDto stats() {
        return new StatsDto(orders.count(), orders.revenue(), products.count(), users.count(),
                products.findByStockLessThanEqualOrderByStockAsc(10).stream().map(ProductService::toDto).toList());
    }
}
