package com.icesneakers.web;

import com.icesneakers.dto.Dtos.*;
import com.icesneakers.model.AppUser;
import com.icesneakers.service.AuthService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final AuthService auth;

    public AuthController(AuthService auth) {
        this.auth = auth;
    }

    @PostMapping("/register")
    @ResponseStatus(HttpStatus.CREATED)
    public UserDto register(@Valid @RequestBody RegisterRequest r, HttpServletRequest req) {
        return auth.register(r, req);
    }

    @PostMapping("/login")
    public UserDto login(@Valid @RequestBody LoginRequest r, HttpServletRequest req) {
        return auth.login(r, req);
    }

    @PostMapping("/logout")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void logout(HttpServletRequest req) {
        auth.logout(req);
    }

    @GetMapping("/me")
    public MeResponse me(HttpSession session) {
        AppUser u = auth.currentUser(session);
        return new MeResponse(u == null ? null : AuthService.toDto(u));
    }
}
