package com.icesneakers.model;

/** Contenedor de enums simples del dominio (se usan como Enums.Gender, etc.). */
public final class Enums {
    private Enums() {}

    public enum Gender { HOMBRE, MUJER, NINOS, UNISEX }

    public enum Role { CLIENTE, ADMIN }

    public enum OrderStatus { PENDIENTE, PAGADO, ENVIADO, ENTREGADO, CANCELADO }
}
